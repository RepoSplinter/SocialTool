import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photo-tags',
  templateUrl: './photo-tags.component.html',
  styleUrls: ['./photo-tags.component.scss'],
})
export class PhotoTagsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
