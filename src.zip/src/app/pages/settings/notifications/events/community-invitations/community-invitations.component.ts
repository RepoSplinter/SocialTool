import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-community-invitations',
  templateUrl: './community-invitations.component.html',
  styleUrls: ['./community-invitations.component.scss'],
})
export class CommunityInvitationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
