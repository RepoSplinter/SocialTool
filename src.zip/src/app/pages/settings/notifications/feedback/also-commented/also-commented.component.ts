import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-also-commented',
  templateUrl: './also-commented.component.html',
  styleUrls: ['./also-commented.component.scss'],
})
export class AlsoCommentedComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
