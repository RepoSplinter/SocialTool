import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-messages',
  templateUrl: './private-messages.component.html',
  styleUrls: ['./private-messages.component.scss'],
})
export class PrivateMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
