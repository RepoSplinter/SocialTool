import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-communities-notifications',
  templateUrl: './communities-notifications.component.html',
  styleUrls: ['./communities-notifications.component.scss'],
})
export class CommunitiesNotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
