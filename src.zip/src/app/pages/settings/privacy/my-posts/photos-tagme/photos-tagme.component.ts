import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photos-tagme',
  templateUrl: './photos-tagme.component.html',
  styleUrls: ['./photos-tagme.component.scss'],
})
export class PhotosTagmeComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
