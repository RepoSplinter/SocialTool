import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-replies-view',
  templateUrl: './replies-view.component.html',
  styleUrls: ['./replies-view.component.scss'],
})
export class RepliesViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
