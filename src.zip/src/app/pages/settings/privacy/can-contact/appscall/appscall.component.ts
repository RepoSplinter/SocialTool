import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appscall',
  templateUrl: './appscall.component.html',
  styleUrls: ['./appscall.component.scss'],
})
export class AppscallComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
