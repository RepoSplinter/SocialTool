import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-friends-requests',
  templateUrl: './friends-requests.component.html',
  styleUrls: ['./friends-requests.component.scss'],
})
export class FriendsRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
