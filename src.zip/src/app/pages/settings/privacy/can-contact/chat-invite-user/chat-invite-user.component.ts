import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-invite-user',
  templateUrl: './chat-invite-user.component.html',
  styleUrls: ['./chat-invite-user.component.scss'],
})
export class ChatInviteUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
