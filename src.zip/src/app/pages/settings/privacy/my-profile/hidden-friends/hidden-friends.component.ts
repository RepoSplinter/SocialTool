import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hidden-friends',
  templateUrl: './hidden-friends.component.html',
  styleUrls: ['./hidden-friends.component.scss'],
})
export class HiddenFriendsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
