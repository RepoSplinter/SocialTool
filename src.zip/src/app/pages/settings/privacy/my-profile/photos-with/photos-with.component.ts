import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photos-with',
  templateUrl: './photos-with.component.html',
  styleUrls: ['./photos-with.component.scss'],
})
export class PhotosWithComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
