export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDWhnoXXUrzJ_54fo8z6YPrKji_b4AUxIY",
    authDomain: "platform-b0282.firebaseapp.com",
    databaseURL: "https://platform-b0282.firebaseio.com",
    projectId: "platform-b0282",
    storageBucket: "platform-b0282.appspot.com",
    messagingSenderId: "488612352600",
    appId: "1:488612352600:web:c9d8bb7541581ffa40f02d"
  }
};
